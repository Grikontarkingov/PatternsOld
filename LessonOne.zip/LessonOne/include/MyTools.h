#pragma once

#include <string>

namespace MyTools {



}; // namespace MyTools
