﻿#include "SBomber.h"


int main(void) {
  SBomber game;
  game.Run();

  system("pause");

  return 0;
}
